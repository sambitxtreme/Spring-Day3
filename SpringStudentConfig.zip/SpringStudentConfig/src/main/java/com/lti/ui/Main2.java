package com.lti.ui;

import java.util.Scanner;

import org.springframework.context.ApplicationContext;
import org.springframework.context.annotation.AnnotationConfigApplicationContext;
import org.springframework.context.support.ClassPathXmlApplicationContext;

import com.lti.config.Appconfig;
import com.lti.model.Student;
import com.lti.service.StudentService;
import com.lti.service.StudentServiceImpl;

public class Main2 {
	private static ApplicationContext context;

	public static void main(String[] args) {
		context=new AnnotationConfigApplicationContext(Appconfig.class);
		StudentService service=context.getBean("service",StudentService.class);
		boolean flag=true;
		do{
		Scanner scan=new Scanner(System.in);
		System.out.println("1.Add Student");
		System.out.println("2.Find Student");
		System.out.println("3.Modify Student");
		System.out.println("4.Delete Student");
		System.out.println("0.Exit Application");
		System.out.println("Enter Your Choice");
		int choice=scan.nextInt();
		switch(choice){
		case 1:
			System.out.println("Enter Student Roll Number");
			int rollNumber=scan.nextInt();
			System.out.println("Enter Student Name");
			String studentName=scan.next();
			System.out.println("Enter STUDENT sCORE");
			double score=scan.nextDouble();
			Student student=context.getBean("student",Student.class);
			student.setRollNumber(rollNumber);
			student.setStudentName(studentName);
			student.setStudentScore(score);
			boolean result=service.addStudent(student);
			if(result){
				System.out.println("Student with roll number"+student.getRollNumber()+" added in database");
			}else{
				System.out.println("There is some technical problem.PLEASE TRY AGAIN!");
			}
			break;
		case 2:
			System.out.println("Enter Rollnumber");
			rollNumber=scan.nextInt();
			
			Student student2=service.findStudentByRollNumber(rollNumber);
			System.out.println(student2);
			break;
		case 3:
			break;
		case 4:
			break;
		case 0:
			flag=false;
		}
		}while(flag);
		

	}

	public static ApplicationContext getContext() {
		return context;
	}

	

}
